
<?php $__env->startSection('content'); ?>

<div class="container pe-auto ps-auto mt-5">
        <div class="row">
            <div class="col-lg-7 col-sm-12 pt-5 ps-auto home" data-aos="fade-right" data-aos-duration="1500">
                <h2 class="tagline typist">Hi, I'm Akmal Maulana.</h2>
                <p class="mt-2">Students of Wikrama Vocational School.</p>
                <div class="action mt-3">
                    <a href="/about" class="btn learn hover.">More About Me</a>
                    <a href="/projects" class="btn project hover.">Project</a>
                </div>
                <div class="mt-5 pt-5 mb-3">
                    <h2>Current Favorite Tech Stack</h2>
                    <div class="row mt-2 tech">
                        <img class="tech-img" src="img/html.png" alt="">
                        <img class="tech-img" src="img/css.png" alt="">
                        <img class="tech-img" src="img/php.png" alt="">
                        <img class="tech-img" src="img/laravel.png" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-sm-12 d-none d-lg-block">
                <img src="https://akmalmaulana.my.id/assets/img/akmal.jpg" data-aos="fade-left" data-aos-duration="1500" class="img-fluid" alt="Responsive image">
            </div>
        </div>
    </div>

    <div class="container ps-auto pe-auto mt-5">
        <div class="row">
            <div class="col-12 ps-auto">
                <h2>Featured Project</h2>
                <div class="row">
                    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-sm-12 mt-3">
                        <div class="card shadow hover." data-aos="fade-in" data-aos-duration="1500">
                            <img src="<?php echo e($item['image']); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($item['title']); ?></h5>
                                <a target="_blank" href="<?php echo e($item['url']); ?>" class="btn btn-primary">Visit</a>
                                <a target="_blank" href="<?php echo e($item['github']); ?>" class="btn btn-dark">Github</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="/project" class="btn w-100 mt-3 btn-more">See More Project <i class="fas fa-link"></i></a>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prod\akmalmaulanabasri\resources\views/home.blade.php ENDPATH**/ ?>