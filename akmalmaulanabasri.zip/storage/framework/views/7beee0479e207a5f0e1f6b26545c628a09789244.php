
<?php $__env->startSection('content'); ?>
<div class="container text-center text-dark bg-secondary pt-5 pb-5 mt-5 mb-5">
    <h2>Coming Soon</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prod\akmalmaulanabasri\resources\views/articles.blade.php ENDPATH**/ ?>