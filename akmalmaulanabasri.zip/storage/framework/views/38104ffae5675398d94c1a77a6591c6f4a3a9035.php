<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Akmal Maulana</title>
    <link rel="stylesheet" href="css/bs.css">
    <link rel="stylesheet" href="css/custom.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/htmltypist.js/dist/typist.css">
    <script src="https://cdn.jsdelivr.net/npm/htmltypist.js/dist/typist.js"></script>
    <script src="https://kit.fontawesome.com/e54b3d474c.js" crossorigin="anonymous"></script>
</head>

<body>

    <nav data-aos="fade-down" data-aos-duration="1500" class="navbar navbar-expand-lg text-light" id="mainNav">
        <div class="container container-custom">
            <a class="navbar-brand text-light" href="/">Akmal Maulana</a>
            <button class="navbar-toggler font-weight-bold bg-dark text-secondary rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded text-light" href="/">Home</a></li>
                    <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded text-light" href="/projects">Project</a></li>
                    <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded text-light" href="/articles">Articles</a></li>
                    <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded text-light" href="/about">About Me</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

            <div class="me container">
                <hr class="mt-3 mb-3">
                    <a class="text-decoration-none text-secondary" href="https://instagram.com/bazzree">Instagram</a>
                    <a class="text-decoration-none text-secondary" href="https://twitter.com/bazzree">Twitter</a>
                    <a class="text-decoration-none text-secondary" href="https://github.com/akmalmaulanabasri">Github</a>
                <h5 class="mt-3 mb-3 text-light">
                    2022 Akmal Maulana
                </h5>
                </div>
            


    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\prod\akmalmaulanabasri\resources\views/layout/app.blade.php ENDPATH**/ ?>