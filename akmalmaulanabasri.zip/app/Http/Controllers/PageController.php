<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{

    public $project = [
        [
            'title' => 'School Profile Website 1',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 1
        ],
        [
            'title' => 'School Profile Website 2',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 1
        ],
        [
            'title' => 'School Profile Website 3',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 1
        ],
        [
            'title' => 'School Profile Website 4',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 1
        ],
        [
            'title' => 'School Profile Website',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 0
        ],
        [
            'title' => 'School Profile Website',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 0
        ],
        [
            'title' => 'School Profile Website',
            'url' => 'https://web-profil-wikrama.akmalmaulana.my.id/',
            'image' => 'https://akmalmaulana.my.id/assets/img/web-wikrama.jpg',
            'github' => 'https://github.com/akmalmaulanabasri/website-smk-wikrama-bogor',
            'featured' => 0
        ]
    ];

    public function topProject(){
        $project = collect($this->project);
        $project = $project->where('featured', 1);
        return $project;
    }

    public function KataBijak(){
        // get data from api
        $data = file_get_contents('https://api.akuari.my.id/randomtext/katabijak');
        $data = json_decode($data, true);
        $data = $data['hasil'];
        return $data;
    }

    public function index(){
        return view('home', ['project' => static::topProject()]);
    }

    public function projects(){
        return view('projects', ['project' => $this->project]);
    }

    public function articles(){
        return view('articles');
    }

    public function about(){
        return view('about', ['kataBijak' => static::KataBijak()]);
    }

}
