@extends('layout.app')
@section('content')
<div class="container mt-5 mb-3">
    <h2>Projects</h2>
    <h4>Daftar Projek-projek yang telah saya buat</h4>

    <div class="row">
        @foreach ($project as $item)
        <div class="col-lg-6 col-sm-12 mt-3">
            <div class="card shadow hover." data-aos="fade-in" data-aos-duration="1500">
                <img src="{{ $item['image'] }}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{ $item['title'] }}</h5>
                    <a target="_blank" href="{{ $item['url'] }}" class="btn btn-primary">Visit</a>
                    <a target="_blank" href="{{ $item['github'] }}" class="btn btn-dark">Github</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection()